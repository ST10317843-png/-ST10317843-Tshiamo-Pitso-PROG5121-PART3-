/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
package test;

import com.sun.net.httpserver.Authenticator.Failure;
import javax.xml.transform.Result;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

    private static Object JUnitCore;
    public static void main(String[] args) {
        Result result = JUnitCore.runClasses(MessageTest.class);
        
        for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
        }
        
        System.out.println("Tests successful: " + result.wasSuccessful());
        System.out.println("Total tests run: " + result.getRunCount());
        System.out.println("Failures: " + result.getFailureCount());
    }
}