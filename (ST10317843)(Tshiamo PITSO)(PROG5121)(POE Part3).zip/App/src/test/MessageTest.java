/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

/**
 *
 * @author RC_Student_lab
 */
import app.Message;
import chat.Message;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    
    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message(1, "+1234567890", "This is a valid message");
        assertTrue(msg.getContent().length() <= 250);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void testMessageLengthFailure() {
        // This test expects the calling code to handle length validation
        String longMessage = new String(new char[251]).replace('\0', 'a');
        Message Message = new Message(1, "+1234567890", longMessage); /*message*/
    }
    
    @Test
    public void testRecipientFormatSuccess() {
        Message msg = new Message(1, "+1234567890", "Valid message");
        assertEquals(1, msg.checkRecipientCell());
    }
    
    @Test
    public void testRecipientFormatFailure() {
        Message msg1 = new Message(1, "1234567890", "Invalid - no +");
        Message msg2 = new Message(1, "+12345678901", "Invalid - too long");
        
        assertEquals(0, msg1.checkRecipientCell());
        assertEquals(0, msg2.checkRecipientCell());
    }
    
    @Test
    public void testMessageHashFormat() {
        Message msg = new Message(1, "+1234567890", "This is a test message");
        String hash = msg.createMessageHash();
        
        assertTrue(hash.startsWith(msg.getMessageId().substring(0, 2)));
        assertTrue(hash.contains(":1:"));
        assertTrue(hash.contains("THIS"));
        assertTrue(hash.contains("MESSAGE"));
    }
    
    @Test
    public void testMessageIdGeneration() {
        Message msg = new Message(1, "+1234567890", "Test message");
        assertTrue(msg.checkMessageID());
        assertEquals(10, msg.getMessageId().length());
    }
    
    @Test
    public void testSentMessageOptions() {
        Message msg = new Message(1, "+1234567890", "Test message");
        
        assertEquals("Message successfully sent", msg.sentMessage(1));
        assertEquals("Press 0 to delete message.", msg.sentMessage(2));
        assertEquals("Message successfully stored", msg.sentMessage(3));
    }

    private void assertTrue(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int i, int checkRecipientCell) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String message_successfully_sent, String sentMessage) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}