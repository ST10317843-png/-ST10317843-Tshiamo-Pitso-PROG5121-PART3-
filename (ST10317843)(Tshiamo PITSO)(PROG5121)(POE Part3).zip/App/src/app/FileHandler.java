/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

/**
 *
 * @author RC_Student_lab
 */

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileHandler {
    private static final String FILE_PATH = "messages.json";

    public void storeMessage(JSONObject message) {
        JSONArray messagesArray;
        
        try {
            // Read existing file
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            messagesArray = new JSONArray(content);
        } catch (IOException e) {
            // File doesn't exist, create new array
            messagesArray = new JSONArray();
        }
        
        // Add new message
        messagesArray.put(message);
        
        // Write back to file
        try (FileWriter file = new FileWriter(FILE_PATH)) {
            file.write(messagesArray.toString(4));
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public JSONArray loadMessages() {
        try {
            String content = new String(Files.readAllBytes(Paths.get(FILE_PATH)));
            return new JSONArray(content);
        } catch (IOException e) {
            return new JSONArray();
        }
    }

    
}