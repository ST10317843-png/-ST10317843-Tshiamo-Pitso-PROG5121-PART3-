/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

/**
 *
 * @author RC_Student_lab
 */





import javax.swing.JOptionPane;
import java.util.HashMap;
import java.util.Map;

public class LoginRegister {
    private Map<String, User> users;
    
    public LoginRegister() {
        this.users = new HashMap<>();
        // Add some test users
        users.put("admin", new User("admin", "password"));
    }
    
    public void showLoginRegisterMenu() {
        while (true) {
            String[] options = {"Login", "Register", "Exit"};
            int choice = JOptionPane.showOptionDialog(null, 
                "Welcome to TalkingChat\nPlease choose an option:", 
                "TalkingChat", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                options, 
                options[0]);
            
            switch (choice) {
                case 0 -> {
                    // Login
                    User user = login();
                    if (user != null) {
                        showMainMenu(user);
                    }
                }
                case 1 -> {
                    // Register
                    User newUser = register();
                    if (newUser != null) {
                        // Automatically log in after registration
                        newUser.login(JOptionPane.showInputDialog("Please confirm your password to login:"));
                        showMainMenu(newUser);
                    }
                }
                case 2 -> // Exit
                    System.exit(0);
                default -> System.exit(0);
            }
        }
    }

    private User login() {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        
        if (users.containsKey(username)) {
            User user = users.get(username);
            if (user.login(password)) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                return user;
            }
        }
        
        JOptionPane.showMessageDialog(null, "Invalid username or password");
        return null;
    }
    
    private User register() {
        String username = JOptionPane.showInputDialog("Enter new username:");
        
        if (users.containsKey(username)) {
            JOptionPane.showMessageDialog(null, "Username already exists");
            return null;
        }
        
        String password = JOptionPane.showInputDialog("Enter new password:");
        String confirmPassword = JOptionPane.showInputDialog("Confirm password:");
        
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(null, "Passwords do not match!");
            return null;
        }
        
        User newUser = new User(username, password);
        users.put(username, newUser);
        
        JOptionPane.showMessageDialog(null, "Registration successful!");
        return newUser;
    }
    
    private void showMainMenu(User user) {
        MessageHandler messageHandler = new MessageHandler();
        
        while (true) {
            String[] options = {"Send Messages", "Show Recent Messages", "Array Operations", "Logout"};
            int choice = JOptionPane.showOptionDialog(null, 
                "Welcome " + user.getUsername() + "!\nChoose an option:", 
                "Main Menu", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                options, 
                options[0]);
            
            switch (choice) {
                case 0 -> // Send Messages
                    messageHandler.sendMessageFlow(user);
                case 1 -> // Show Recent Messages
                    messageHandler.showRecentMessages();
                case 2 -> // Array Operations
                    showArrayOperationsMenu(messageHandler, user);
                case 3 -> {
                    // Logout
                    user.logout();
                    return; // Return to login/register menu
                }
                case -1 -> {
                    // Window closed
                    return;
                }
                default -> {
                    return;
                }
            }
        }
    }
    
    private void showArrayOperationsMenu(MessageHandler messageHandler, User user) {
        String[] options = {
            "Display Senders/Recipients",
            "Display Longest Message",
            "Search by Message ID",
            "Search by Recipient",
            "Delete by Message Hash",
            "Display Full Report",
            "Back to Main Menu"
        };
        
        while (true) {
            int choice = JOptionPane.showOptionDialog(null, 
                "Array Operations Menu\nChoose an option:", 
                "Array Operations", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                options, 
                options[0]);
            
            switch (choice) {
                case 0 -> // Display Senders/Recipients
                    messageHandler.displaySendersAndRecipients();
                case 1 -> // Display Longest Message
                    messageHandler.displayLongestMessage();
                case 2 -> {
                    // Search by Message ID
                    String id = JOptionPane.showInputDialog("Enter Message ID to search:");
                    if (id != null) messageHandler.searchByMessageId(id);
                }
                case 3 -> {
                    // Search by Recipient
                    String recipient = JOptionPane.showInputDialog("Enter Recipient to search:");
                    if (recipient != null) messageHandler.searchByRecipient(recipient);
                }
                case 4 -> {
                    // Delete by Message Hash
                    String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                    if (hash != null) messageHandler.deleteByHash(hash);
                }
                case 5 -> // Display Full Report
                    messageHandler.displayFullReport();
                case 6, -1 -> // Back to Main Menu
                {
                    // Window closed
                    return;
                }
                default -> {
                    return;
                }
            }
            // Back to Main Menu
                    }
    }
}