/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

/**
 *
 * @author RC_Student_lab
 */


import app.FileHandler;
import app.Message;
import app.User;
import javax.swing.JOptionPane;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

    private Object sentMessages;
    private Object messageHashes;
    private Object messageIds;
public class MessageHandler {
    private List<Message> sentMessages;
    private List<Message> disregardedMessages;
    private List<Message> storedMessages;
    private List<String> messageHashes;
    private List<String> messageIds;
    private int totalMessages;
    private FileHandler fileHandler;

    public MessageHandler() {
            this.message = new Message(totalMessages, recipient, content);
        this.sentMessages = new ArrayList<>();
        this.disregardedMessages = new ArrayList<>();
        this.storedMessages = new ArrayList<>();
        this.messageHashes = new ArrayList<>();
        this.messageIds = new ArrayList<>();
        this.totalMessages = 0;
        this.fileHandler = new FileHandler();
    }

    public void sendMessageFlow(User user) {
    if (!user.isLoggedIn()) {
        JOptionPane.showMessageDialog(null, "Please login first!");
        return;
    }

    String numMessagesStr = JOptionPane.showInputDialog("How many messages would you like to send?");
    int numMessages;
    try {
        numMessages = Integer.parseInt(numMessagesStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Please enter a valid number");
        return;
    }

    for (int i = 0; i < numMessages; i++) {
        String recipient = JOptionPane.showInputDialog("Enter recipient's phone number (with international code, e.g., +27614568888):");
        
        // Validate phone number format
        if (!recipient.startsWith("+") || recipient.length() > 15 || !recipient.substring(1).matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Invalid phone number format. Please include country code (e.g., +27614568888)");
            i--; // retry this message
            continue;
        }

        String content = JOptionPane.showInputDialog("Enter your message (max 250 chars):");
        // Rest of your message handling code...
    }
}

            totalMessages++;
            Message message;

            String[] options = {"Send Message", "Store Message", "Disregard Message"};
            int choice = JOptionPane.showOptionDialog(null, 
                "Choose an action for this message:", 
                "Message Action", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.INFORMATION_MESSAGE, 
                null, 
                options, 
                options[0]);

            String result = message.sentMessage(choice + 1);
            JOptionPane.showMessageDialog(null, result);

            // Add to appropriate lists
            if (message.isSent()) {
                sentMessages.add(message);
                messageHashes.add(message.getMessageHash());
                messageIds.add(message.getMessageId());
                
                // Display message details
                String details = "Message ID: " + message.getMessageId() + "\n" +
                                "Message Hash: " + message.getMessageHash() + "\n" +
                                "Recipient: " + message.getRecipient() + "\n" +
                                "Message: " + message.getContent();
                JOptionPane.showMessageDialog(null, details);
            } else if (message.isStored()) {
                storedMessages.add(message);
                fileHandler.storeMessage(message.toJson());
            } else if (message.isDisregarded()) {
                disregardedMessages.add(message);
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessages);
    }

    public void showRecentMessages() {
    Iterable<Message> sentMessages = null;
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Recently Sent Messages:\n\n");
        for (Message msg : sentMessages) {
            sb.append("To: ").append(msg.getRecipient()).append("\n");
            sb.append("Message: ").append(msg.getContent().substring(0, Math.min(20, msg.getContent().length())));
            if (msg.getContent().length() > 20) sb.append("...");
            sb.append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Array manipulation methods for Part 3
    public void displaySendersAndRecipients(Iterable<Message> sentMessages) {
        StringBuilder sb = new StringBuilder();
        sb.append("Senders and Recipients:\n\n");
        for (Message msg : sentMessages) {
            sb.append("From: You\n");
            sb.append("To: ").append(msg.getRecipient()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.getContent().length() > longest.getContent().length()) {
                longest = msg;
            }
        }

        String details = """
                         Longest Message:
                         
                         To: """ + longest.getRecipient() + "\n" +
                        "Length: " + longest.getContent().length() + " characters\n" +
                        "Message: " + longest.getContent();
        JOptionPane.showMessageDialog(null, details);
    }

    public void searchByMessageId(String id) {
        for (Message msg : sentMessages) {
            if (msg.getMessageId().equals(id)) {
                String details = """
                                 Message Found:
                                 
                                 To: """ + msg.getRecipient() + "\n" +
                                "Message: " + msg.getContent();
                JOptionPane.showMessageDialog(null, details);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No message found with ID: " + id);
    }

    public void searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        sb.append("Messages to ").append(recipient).append(":\n\n");
        boolean found = false;
        
        for (Message msg : sentMessages) {
            if (msg.getRecipient().equals(recipient)) {
                sb.append("Message ID: ").append(msg.getMessageId()).append("\n");
                sb.append("Message: ").append(msg.getContent()).append("\n\n");
                found = true;
            }
        }
        
        if (found) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipient);
        }
    }

    public void deleteByHash(String hash) {
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).getMessageHash().equals(hash)) {
                sentMessages.remove(i);
                messageHashes.remove(i);
                messageIds.remove(i);
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No message found with hash: " + hash);
    }

    public void displayFullReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("MESSAGE REPORT\n\n");
        sb.append("Total Messages Sent: ").append(sentMessages.size()).append("\n\n");
        
        for (Message msg : sentMessages) {
            sb.append("Message ID: ").append(msg.getMessageId()).append("\n");
            sb.append("Recipient: ").append(msg.getRecipient()).append("\n");
            sb.append("Message Hash: ").append(msg.getMessageHash()).append("\n");
            sb.append("Content: ").append(msg.getContent()).append("\n\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // Getters for arrays
    public List<Message> getSentMessages() { return sentMessages; }
    public List<Message> getDisregardedMessages() { return disregardedMessages; }
    public List<Message> getStoredMessages() { return storedMessages; }
    public List<String> getMessageHashes() { return messageHashes; }
    public List<String> getMessageIds() { return messageIds; }
}