/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;

/**
 *
 * @author RC_Student_lab
 */

import org.json.JSONObject;
import java.util.Random;

public class Message {
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String content;
    private String messageHash;
    private boolean isSent;
    private boolean isStored;
    private boolean isDisregarded;

    public Message(int messageNumber, String recipient, String content) {
        this.messageId = generateMessageId();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.content = content;
        this.messageHash = createMessageHash();
        this.isSent = false;
        this.isStored = false;
        this.isDisregarded = false;
    }

   

    

    private String generateMessageId() {
        Random rand = new Random();
        long id = 1000000000L + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        return this.messageId.length() == 10;
    }

    public int checkRecipientCell() {
        if (recipient.startsWith("+") && recipient.length() <= 10) {
            return 1; // valid
        }
        return 0; // invalid
    }

    public final String createMessageHash() {
        String[] words = content.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        return (messageId.substring(0, 2) + ":" + messageNumber + ":" + 
               firstWord.toUpperCase() + "_" + lastWord.toUpperCase());
    }

    public String sentMessage(int choice) {
        switch (choice) {
            case 1 -> {
                this.isSent = true;
                return "Message successfully sent";
            }
            case 2 -> {
                this.isDisregarded = true;
                return "Press 0 to delete message.";
            }
            case 3 -> {
                this.isStored = true;
                return "Message successfully stored";
            }
            default -> {
                return "Invalid choice";
            }
        }
    }

    public String printMessage() {
        return "Total messages sent: " + messageNumber;
    }

    public int returnTotalMessages() {
        return messageNumber;
    }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("messageId", messageId);
        json.put("messageNumber", messageNumber);
        json.put("recipient", recipient);
        json.put("content", content);
        json.put("messageHash", messageHash);
        json.put("isSent", isSent);
        json.put("isStored", isStored);
        json.put("isDisregarded", isDisregarded);
        return json;
    }

    // Getters and Setters
    public String getMessageId() { return messageId; }
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getMessageHash() { return messageHash; }
    public boolean isSent() { return isSent; }
    public boolean isStored() { return isStored; }
    public boolean isDisregarded() { return isDisregarded; }

    
}